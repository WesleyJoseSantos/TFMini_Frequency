//*************************************************************************************************/
//   Projeto    : TFmini Frequency
//   Arquivo    : freq_out.h
//   Descri��o  : Fun��es para manipula��o da sa�da de frequ�ncia
//   Data       : 17/09/2019
//*************************************************************************************************/

#ifndef freq_h
#define freq_h

#include "spider.h"
#include "parameters.h"
#include "tfmini.h"

#define pinDist 4

void freq_setup()
{
    pinMode(pinDist, OUTPUT);
}

uint16_t freq_out(uint16_t val, uint16_t inMin, uint16_t inMax, uint16_t outMin, uint16_t outMax, byte pin)
{   
    if(outMin < 33) outMin = 33;
    if(outMax > 1023) outMax = 1023;
    uint16_t freq = map(val, inMin, inMax, outMin, outMax);
    tone(pin, freq);
    return(freq);
}

void freq_set_reg(unsigned int reg, unsigned int value)
{
    spider_setReg(reg, value);
}

void freq_update()
{
    uint16_t inMin = 0;
    uint16_t inMax = 200;
    uint16_t outMin = 33;
    uint16_t outMax = 1023;
    uint16_t freqDist = freq_out(tfDist, inMin, inMax, outMin, outMax, pinDist);
    Serial.print("tfDist = "); Serial.print(tfDist); Serial.print("\t");
    Serial.print("Freq = "); Serial.println(freqDist);
}

#endif
