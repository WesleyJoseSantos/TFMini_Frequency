//*************************************************************************************************/
//   Projeto    : TFmini Frequency
//   Arquivo    : spider.h
//   Descri��o  : Fun��es para manipula��o da cominica��o com o software TFspider
//   Data       : 17/09/2019
//*************************************************************************************************/

#ifndef spider_h
#define spider_h

#include "BqBusCmd.h"
#include "parameters.h"

BqBusCmd spider = BqBusCmd(20);

enum idx
{
    idx_temp_val,
    idx_temp_freq,
    idx_dist_val,
    idx_dist_freq,
    idx_lux_val,
    idx_lux_freq,
    idx_temp_val_min,
    idx_temp_val_max,
    idx_temp_freq_min,
    idx_temp_freq_max,
    idx_dist_val_min,
    idx_dist_val_max,
    idx_dist_freq_min,
    idx_dist_freq_max,
    idx_lux_val_min,
    idx_lux_val_max,
    idx_lux_freq_min,
    idx_lux_freq_max,
    idx_cmd_word1
};

#define cmd_save idx_cmd_word1,0
#define cmd_load idx_cmd_word1,1

void spider_load_parameters()
{
    parameters_load();
    for(int i = 6; i <= 17; i++)
    {
        spider.setReg(i, parameters_get(i - 6));
    }
}

void spider_save_parameters()
{
    for(int i = 6; i <= 17; i++)
    {
        parameters_set(i - 6, spider.getReg(i));
    }
    parameters_save();
}

void spider_setup()
{
    spider.begin(115200);
    pinMode(13, OUTPUT);
    spider_load_parameters();
}

void spider_update()
{
    spider.updateRegs();
    if(spider.getRegBit(cmd_save))
    {
        digitalWrite(13, HIGH);
        spider_save_parameters();
        digitalWrite(13, LOW);
    }
    if(spider.getRegBit(cmd_load))
    {
        digitalWrite(13, HIGH);
        spider_load_parameters();
        digitalWrite(13, LOW);
    }
}

unsigned int spider_getReg(int id)
{
    return(spider.getReg(id));
}

void spider_setReg(unsigned int id, unsigned int value)
{
    spider.setReg(id, value);
}

#endif