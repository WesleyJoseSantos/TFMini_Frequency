//*************************************************************************************************/
//   Projeto    : TFmini Frequency
//   Arquivo    : TFmini.h
//   Descri��o  : Fun��es para a manipula��o da comunica��o com o software TFmini
//   Data       : 17/09/2019
//*************************************************************************************************/

#ifndef TFmini_h
#define TFmini_h

#include "TFMPlus.h"
#include "SoftwareSerial.h"

TFMPlus tfmp;
SoftwareSerial serialMini = SoftwareSerial(2, 3);

uint16_t tfDist;       // Distance measurement in centimeters (default)
uint16_t tfLux;        // Luminous flux or intensity of return signal
uint16_t tfTemp;       // Temperature in degrees Centigrade (coded)

void tfmini_setup()
{
    serialMini.begin(115200);
    delay(20);
    tfmp.begin(&serialMini);
}

void tfmini_update()
{
    tfmp.getData(tfDist, tfLux, tfTemp);
}

#endif