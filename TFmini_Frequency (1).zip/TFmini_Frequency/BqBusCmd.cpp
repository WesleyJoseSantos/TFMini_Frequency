//*************************************************************************************************/
//   Projeto    : BqBusCmd
//   Arquivo    : BqBusCmd.cpp
//   Descri��o  : Implementa��o das estruturas da biblioteca
//   Data       : 19/10/2019
//*************************************************************************************************/

#include "BqBusCmd.h"

BqBusCmd::BqBusCmd()
{
    initVars();
    initRegs(10);
    _BqPort = &Serial;
}

BqBusCmd::BqBusCmd(byte numMaxRegs)
{
    initVars();
    initRegs(numMaxRegs);
    _BqPort = &Serial;
}

BqBusCmd::BqBusCmd(byte numMaxRegs, HardwareSerial *BqPort)
{
    initVars();
    initRegs(numMaxRegs);
    _BqPort = BqPort;
}

void BqBusCmd::initVars()
{
    _regPos    = 0;
    _digit     = 0;
    _digitAux  = 0;
    _setOn     = false;
    _readDone  = false;
    _writeDone = false;
}

void BqBusCmd::initRegs(uint16_t numMaxRegs)
{
    _numMaxRegs = numMaxRegs;
    for(size_t i = 0; i < 8; i++)
    {
        regToChange[i] = 0;
    }
    if(regs != 0)
    {
        delete [] regs;
    }
    regs = new uint16_t [_numMaxRegs];
    for(size_t i = 0; i < _numMaxRegs; i++){
        regs[i] = 0;
    }
}

void BqBusCmd::begin(long baudRate)
{
    _BqPort->begin(baudRate);
}

void BqBusCmd::updateRegs()
{
    _digit = 0;
    while(_BqPort->available() > 0)
    {
        _digit = _BqPort->read();
        readDigit(_digit);
        if(_digit == '_')
        {
            _readDone = true;
        }
    }
    if(_readDone)
    {
        writeResponse();
        _readDone = false;
    }
}

uint8_t BqBusCmd::getRegToChangeIdx(uint16_t regPos)
{
    return(regPos/32);
}

void BqBusCmd::readDigit(char digitToRead)
{
    if(digitToRead != '.' && digitToRead != '_')
    {
        _digitAux = _digitAux * 10 + digitToRead - 48;
    }
    if(digitToRead == '.')
    {
        int i = getRegToChangeIdx(_regPos);
        if(!bitRead(regToChange[i], _regPos))
        {
            regs[_regPos] = _digitAux;
            _regPos++;
            _digitAux = 0;
        }
        else
        {
            bitWrite(regToChange[i], _regPos, false);
            _regPos++;
            _digitAux = 0;
        }
    }
    if(digitToRead == '_')
    {
        _regPos = 0;
        _digitAux = 0;
    }
}

void BqBusCmd::writeResponse()
{
    for(size_t i = 0; i < _numMaxRegs; i++)
    {
        _BqPort->print(regs[i]);
        _BqPort->print('.');
    }
    _BqPort->print('_');
    _writeDone = true;
}

bool BqBusCmd::writeComplete()
{
    bool ret = _writeDone;
    _writeDone = 0;
    return(ret);
}

void BqBusCmd::writeResponse(size_t count)
{
    for(size_t i = 0; i < count; i++)
    {
        _BqPort->println(regs[i]);
        _BqPort->print('.');
    }
    _BqPort->println('_');
    _writeDone = true;
}

uint16_t BqBusCmd::getReg(uint16_t regAddress)
{
    return(regs[regAddress]);
}

void BqBusCmd::setReg(uint16_t regAddress, uint16_t value)
{
    if(regs[regAddress] != value)
    {
        regs[regAddress] = value;
        int i = getRegToChangeIdx(regAddress);
        bitWrite(regToChange[i], regAddress, true);
    }
}

bool BqBusCmd::getRegBit(uint16_t regAddress, uint8_t bitAddress)
{
    return(bitRead(regs[regAddress], bitAddress));
}

void BqBusCmd::setRegBit(uint16_t regAddress, uint8_t bitAddress, bool state)
{
    if(bitRead(regs[regAddress], bitAddress) != state)
    {
        bitWrite(regs[regAddress], bitAddress, state);
        int i = getRegToChangeIdx(regAddress);
        bitWrite(regToChange[i], regAddress, true);
    }
}

