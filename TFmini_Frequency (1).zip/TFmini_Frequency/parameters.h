//*************************************************************************************************/
//   Projeto    : TFmini Frequency
//   Arquivo    : Parameters.h
//   Descri��o  : Fun��es para a manipula��o dos par�metros de configura��o do m�dulo
//   Data       : 17/09/2019
//*************************************************************************************************/

#ifndef parameters_h
#define parameters_h

#include "EEPROM.h"

enum parameters_ids
{
    temp_val_min,
    temp_val_max,
    temp_freq_min,
    temp_freq_max,
    dist_val_min,
    dist_val_max,
    dist_freq_min,
    dist_freq_max,
    lux_val_min,
    lux_val_max,
    lux_freq_min,
    lux_freq_max
};

unsigned int parameters_data[12];

void parameters_load()
{
    for(int i = 0; i < 12; i++)
    {
        long data = EEPROM.get(i*2, parameters_data[i]);
        if(data < 0) data = 0;
        if(data > 1023) data = 1023;
        parameters_data[i] = data;
    }
}

void parameters_save()
{
    for(int i = 0; i < 12; i++)
    {
        EEPROM.put(i*2, parameters_data[i]);
    }
}

unsigned int parameters_get(int id)
{
    return(parameters_data[id]);
}

void parameters_set(int id, unsigned int val)
{
    parameters_data[id] = val;
}
#endif