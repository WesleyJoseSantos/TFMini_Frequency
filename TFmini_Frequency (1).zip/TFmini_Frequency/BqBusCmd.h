//*************************************************************************************************/
//   Projeto    : BqBusCmd
//   Arquivo    : BqBusCmd.h
//   Descri��o  : Declara��o das estruturas da biblioteca
//   Data       : 19/10/2019
//*************************************************************************************************/

#ifndef BqBusCmd_h
#define BqBusCmd_h

#include <Arduino.h>

class BqBusCmd                                                              //O BqBusCmd � um protocolo de comunica��o que trafega registradores (vari�veis de 16bits) \nenviando e interpretando strings atrav�s da porta serial do Arduino
{
public:
    BqBusCmd();                                                             //Inicializa a instancia com as configura��es padr�o
    BqBusCmd(byte numMaxRegs);                                              //Inicializa a instancia definindo a quantidade de registradores
    BqBusCmd(byte numMaxRegs, HardwareSerial *BqPort);                      //Inicializa a instancia definindo a quantidade de registradores e a porta serial utilizada
    void begin(long baudRate);                                              //Inicializa a rede com a velocidade especificada
    void updateRegs();                                                      //Realiza um ciclo da rede, atualizando os registradores atrav�s da comunica��o serial
    uint16_t getReg(uint16_t regAddress);                                   //Obt�m o valor de um registrador
    void setReg(uint16_t regAddress, uint16_t value);                       //Define o valor de um registrador
    bool getRegBit(uint16_t regAddress, uint8_t bitAddress);                //Obt�m o valor de um bit de um registrador
    void setRegBit(uint16_t regAddress, uint8_t bitAddress, bool state);    //Define o valor de um bit de um registrador
private:
    HardwareSerial *_BqPort;
    byte _numMaxRegs;
    uint16_t *regs, _digit, _regPos, _digitAux;
    uint32_t regToChange[8];
    uint8_t getRegToChangeIdx(uint16_t regPos);
    bool _setOn, _readDone, _writeDone;
    void initVars();
    void initRegs(uint16_t numMaxRegs);
    void readDigit(char digit);
    void writeResponse();
    void writeResponse(size_t count);
    bool writeComplete();
};

#endif